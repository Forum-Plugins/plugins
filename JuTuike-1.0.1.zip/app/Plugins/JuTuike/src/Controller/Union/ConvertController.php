<?php

namespace App\Plugins\JuTuike\src\Controller\Union;

use Hyperf\HttpServer\Annotation\Controller;
use Hyperf\HttpServer\Annotation\GetMapping;
use Hyperf\HttpServer\Annotation\PostMapping;

#[Controller(prefix: '/act')]
class ConvertController
{
    #[GetMapping("")]
    public function index()
    {
        return view('JuTuike::union.convert');
    }

    #[PostMapping("")]
    public function store(): array
    {
        $content = request()->input('content');
        if (empty($content)) {
            return json_api(400, false, '请输入内容');
        }
        return jutuike_union_convert($content);
    }
}