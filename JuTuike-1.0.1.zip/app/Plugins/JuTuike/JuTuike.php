<?php

namespace App\Plugins\JuTuike;

class JuTuike
{
    public function handler()
    {
        require_once __DIR__ . '/bootstrap.php';
        require_once __DIR__ . '/helper.php';

    }
}