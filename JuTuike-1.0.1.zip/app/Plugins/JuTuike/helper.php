<?php

if (!function_exists('jutuike_union_convert')){
    /**
     * 电商聚合转链API接口
     * @param string $content
     * @return array
     */
    function jutuike_union_convert(string $content): array
    {
        $content = get_first_link($content);
        $content = urlencode($content);
        try {
            $res = http()->post('http://api.act.jutuike.com/union/wn_convert',[
                'pub_id' => get_options('Jutuike_pubid'),
                'app_key' => get_options('Jutuike_apikey'),
                'content' => $content,
            ]);
        }catch (\Exception $exception){
            return json_api(400,false,$exception->getMessage());
        }
        if((int)$res['code']!==1){
            return json_api(400,false,$res['msg']);
        }
        $goodsId = $res['data']['goodsId'];
        $source = $res['data']['source'];
        try {
            $res = http()->post('http://api.act.jutuike.com/union/convert',[
                'pub_id' => get_options('Jutuike_pubid'),
                'app_key' => get_options('Jutuike_apikey'),
                'sid' => 'runpodCnAct',
                'goodsId' => $goodsId,
                'source' => $source,
            ]);
        }catch (\Exception $exception){
            return json_api(400,false,$exception->getMessage());
        }
        if((int)$res['code']!==1){
            return json_api(400,false,$res['msg']);
        }
        $data = $res['data'];
        $data['source'] = $source;
        return json_api(200,true,$data);
    }
}

if(!function_exists('get_first_link')){
    /**
     * 获取第一个链接
     * @param string $content
     * @return string
     */
    function get_first_link(string $content): string
    {
        $pattern = '/(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-)+)/';
        preg_match_all($pattern, $content, $matches);
        if (isset($matches[0][0])) {
            return $matches[0][0];
        }

        return '';
    }
}