import axios from "axios";
import copy from "copy-to-clipboard";

if(document.getElementById('tuike-act')){
    const app = {
        data(){
            return {
                content:null,
                url : null,
                isText:false,
                result:null,
                loading:false
            }
        },
        mounted() {
            if (navigator.clipboard) {
                // 从剪贴板中读取文本内容
                navigator.clipboard.readText()
                    .then(text => {
                        this.content = text
                        // 在这里可以对剪贴板内容进行处理
                    })
            }
        },
        methods:{
            submit(){
                if(!this.content){
                    alert("请输入内容")
                    return ;
                }
                this.loading = true
                axios.post('/act',{
                    _token:csrf_token,
                    content:this.content
                }).then(res=>{
                    let data = res.data
                    if(data.success===false){
                        alert(data.result)
                        this.content = null
                        this.url = null
                        this.isText = false
                        this.result = null
                        this.loading = false
                        return ;
                    }
                    let result = data.result
                    this.url = result.url
                    // 判断this.url 是否是一个url
                    let reg = new RegExp("^(http|https)://","i")
                    // 如果是文字
                    if(!reg.test(this.url)){
                        this.content = "请复制这段口令返回"+result.source+"打开：\n"+this.url
                        this.isText = true
                        this.result = result
                        this.loading = false
                        return ;
                    }
                    this.content = null
                    this.result = result
                    this.loading = false

                }).catch(err=>{
                    console.log(err)
                    alert("出错了！")
                })
            },
            buy(){
                // 判断this.url 是否是一个url
                let reg = new RegExp("^(http|https)://","i")
                // 如果是url
                if(!reg.test(this.url)){
                    this.content = "请复制这段口令返回"+this.result.source+"打开：\n"+this.url
                    this.isText = true
                    copy(this.url)
                    swal("请复制下方内容",this.content,"success").then(a=>{
                        copy(this.content)
                    })
                    return ;
                }
                window.open(this.url, '_blank');
            }
        },
    }
    Vue.createApp(app).mount('#tuike-act')
}