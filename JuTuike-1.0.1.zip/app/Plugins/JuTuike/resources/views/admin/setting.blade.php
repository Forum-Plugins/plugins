<div class="card card-body">
    <div class="row">

        <div class="col-md-6 col-lg-4">
            <div class="form-label">身份ID Pubid</div>
            <input type="text" v-model="data.Jutuike_pubid" class="form-control" placeholder="pubid" >
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="form-label">开发api key</div>
            <input type="text" v-model="data.Jutuike_apikey" class="form-control" placeholder="apikey" >
        </div>

    </div>


</div>