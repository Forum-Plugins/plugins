@extends('App::app')
@section('title','淘宝、抖音、京东、拼多多 下单优惠链接获取')
@section('description','淘宝｜京东｜拼多多｜抖音 优惠券获取、领券下单')
@section('keyword','淘宝优惠券、京东优惠券、拼多多优惠券')
@section('content')
    <style>
        [v-cloak] {
            display: none;
        }
    </style>
<div class="row row-cards">
    <div class="col-12">
        <div class="card" id="tuike-act">
            <div class="card-header">
                <h3 class="card-title">领券下单，尽享优惠</h3>
            </div>
            <div class="card-body">
                <span style="font-size: 16px" class="text-muted"> 5秒快速记住本站链接：<span class="text-red">runpod.cn/act</span>  </span>
                <p style="font-size: 16px" class="text-muted mt-2">多数商品基本都有隐藏优惠券，养成先查询再下单的习惯，能帮你省下不少钱。</p>
                <p style="font-size: 16px" class="text-muted mt-2">支持：<span class="text-warning">淘宝、京东、拼多多、抖音</span></p>
            </div>
            <div class="card-body">
                <form class="row justify-content-center" @@submit.prevent="submit">
                    <div class="align-center text-center">
                        <textarea required class="form-control" rows="3" v-model="content" placeholder="请输入商品链接"></textarea>
                    </div>
                    <div class="mt-3">
                        <button class="btn btn-primary" :disabled="loading"><span class="spinner-border spinner-border-sm me-2" role="status" v-if="loading"  v-cloak></span>获取优惠链接</button>
                    </div>
                </form>
            </div>
            <div class="card-body" v-if="result" v-cloak>
                <h3 class="card-title" style="font-size: 1.3rem">@{{ result.goodsName }}</h3>
                <div class="mb-3">
                    <div class="badge bg-warning-lt mx-2">原价：@{{ result.marketPrice }}</div>
                    <div class="badge bg-warning-lt mx-2">劵后价：@{{ result.price }}</div>
                    <div v-if="result.discount>0" class="badge bg-warning-lt mx-2">折扣：@{{ result.discount }}</div>
                    <p><button @@click="buy" v-if="url" class="btn btn-warning mx-2 mt-2">立即领券购买</button></p>
                </div>
                <div class="row">
                    <div v-for="pic in result.goodsCarouselPictures" class="col-4 col-md-3 col-lg-2">
                        <img :src="pic" alt="pic">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script src="{{file_hash('plugins/JuTuike/js/act.js')}}"></script>
@endsection