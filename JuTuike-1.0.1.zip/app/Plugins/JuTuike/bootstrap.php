<?php

Itf_Setting()->add(
    12229,
    '聚推客',
    'JuTuike',
    'JuTuike::admin.setting'
);